package cas2xb3.greenlight;

/*
 * Class to implement binary search.
 * 
 * @author Yousaf Shaheen
 * @since   2017-03-09
 */
public class BinarySearch {
	
	
	
	
	/*
	 * This method implements Binary search.
	 * Takes in high and low index values to search sub arrays in the given array.
	 * Uses comparable interface.
	 * Throws IndexOutOfBoundsException if indexes are invalid.
	 * 
	 * @param x Given array to search
	 * @param item Item to be searched for
	 * @param lo lower index value - INCLUSIVE
	 * @param hi higher index value - EXCLUSIVE
	 * @return True if the value given is in the given array.
	 */
	public static boolean search (Comparable[][] x, Comparable item, int type, int lo, int hi) {
		
		if(lo < 0){
			throw new IndexOutOfBoundsException("Lower bound invalid");
		}else if(hi > x.length){
			throw new IndexOutOfBoundsException("Upper bound invalid");
		}
		
		while (hi > lo) {
			int mid = (hi + lo) / 2;
			if (item.compareTo(x[mid][type]) == -1) {
				hi = mid;
			} else if (item.compareTo(x[mid][type]) == 1) {
				lo = mid + 1;
			} else if (item == x[mid][type]) {
				return true;
			}
		}
		return false;
	}
	
}
