package cas2xb3.greenlight;

public class ge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String n = "Toronto Iowa";
		
		String m = "Toronto";
		
		if(!n.contains("Iowa")){
			n = n + " Iowa";
		}
		
		System.out.println(n);
	}

}
