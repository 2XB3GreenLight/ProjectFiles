package cas2xb3.greenlight;

public class Merge {
	/**
	 * merge sort using Comparable
	 * @param x - the input array containing times of jobs that need to be sorted.
	 * @param n - the size of the input array
	 */
	public static void sortMerge ( Comparable[] x, int n ) {
		Comparable[] aux = new Comparable[n];
		sort(x, 0, n-1);
	}
	
	private static void sort(Comparable[] x, int lo, int hi){
		if (hi <= lo)
			return;
		int mid = lo + (hi - lo) / 2;
		sort(x,lo,mid);
		sort(x,mid+1,hi);
		merge(x,lo,mid, hi);
	}
	
	private static boolean less(Comparable v, Comparable w){
		return v.compareTo(w) < 0;
	}
	
	private static void merge(Comparable[] x, int lo, int mid, int hi){
		int i = lo;
		int j = mid + 1;
		Comparable[] aux = new Comparable[x.length];
		
		for (int k = lo; k <= hi; k++){
			aux[k] = x[k];
		}
		
		for (int k = lo; k <= hi; k++){
			if (i > mid)
				x[k] = aux[j++];
			else if (j > hi)
				x[k] = aux[i++];
			else if (less(aux[j], aux[i]))
				x[k] = aux[j++];
			else
				x[k] = aux[i++];
		}
	}
}
