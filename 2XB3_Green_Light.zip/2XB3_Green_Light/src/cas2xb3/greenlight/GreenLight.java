package cas2xb3.greenlight;

import java.util.Scanner;

public class GreenLight {

	public static void main(String[] args) {
		
		// Take the input from the user:
		/*
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Insert x-coordinate of destination: ");
		double xcrd = keyboard.nextDouble();
		System.out.println("Insert y-coordinate of destination: ");
		double ycrd = keyboard.nextDouble();
		*/
		
		Data.getArray();
		Heap.sort(Data.getArray(), 5);
		Data.printArray();
		//System.out.println(Data.equation(80681));
	}

}
