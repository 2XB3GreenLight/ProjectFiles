package cas2xb3.greenlight;

/**
 * An ADT class for collisions.
 * 
 * @author Mediha Munim
 *
 */
public class Collision implements Comparable {

	private int index;
	private double latitude;
	private double longitude;
	private int severity;
	private int weather;
	private int paved;

	/**
	 * Creates a collision object given the crash index, the latitude, the
	 * longitude, the crash severity, the weather, and if the road was paved.
	 * 
	 * @param index
	 *            The index used to reference the collision.
	 * @param lat
	 *            The latitude at which the crash occurred.
	 * @param lng
	 *            The longitude at which the crash occurred.
	 * @param CSEV
	 *            The crash severity.
	 * @param weather
	 *            The weather at the time/place of the collision.
	 * @param paved
	 *            Whether or not the road is paved. (2 = unpaved, 1 = paved)
	 */
	public Collision(int index, double lat, double lng, int CSEV, int weather, int paved) {
		this.index = index;
		latitude = lat;
		longitude = lng;
		severity = CSEV;
		this.weather = weather;
		this.paved = paved;
	}

	/**
	 * Returns the collision index/identifier.
	 * 
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Returns the latitude at which the crash occurred.
	 * 
	 * @return the latitude.
	 */
	public double getLat() {
		return latitude;
	}

	/**
	 * Returns the longtitude at which the crash occurred.
	 * 
	 * @return the longitude.
	 */
	public double getLng() {
		return longitude;
	}

	/**
	 * Returns a number indicating how severe the crash was on a scale from 1-5.
	 * 1 = very severe, 5 = nonsevere.
	 * 
	 * @return the collision severity.
	 */
	public int getSeverity() {
		return severity;
	}

	/**
	 * Returns a number indicating weather collisions on a scale from 1-10.. 1 =
	 * sunny/pleasant weather, 10 = bad weather.
	 * 
	 * @return The collisions' weather.
	 */
	public int getWeather() {
		return weather;
	}

	/**
	 * Returns whether or not the road was paved at the time/place of the
	 * collision.
	 * 
	 * @return 1 if the road was paved, 2 if the road wasn't paved.
	 */
	public int getPaved() {
		return paved;
	}

	/**
	 * Calculates the collision importance/how much a collision location should
	 * be avoided. A crash is considered important to the dataset if the crash
	 * was severe and if the road is unpaved. If the weather was severe (and
	 * potentially the cause of the collision), a collision is considered less
	 * important.
	 * 
	 * @return the collision importance.
	 */
	public double getEquation() {
		return (1.0 / (2 * getSeverity()) + 1 / (5 * getWeather())) * (0.9 + (getPaved() / 10));
	}

	/**
	 * Compares the collision to another collision. Uses latitude as a means of
	 * comparison in order to sort them.
	 * 
	 * @param o
	 *            The object (collision) with which to compare the collision.
	 * @return 1 if the collision has a greater latitude, -1 if it has a lower
	 *         latitude, and 0 if they have the same latitude.
	 */
	@Override
	public int compareTo(Object o) {
		Collision c = (Collision) o;
		if (this.latitude == c.latitude)
			return 0;
		else
			return this.latitude > c.latitude ? 1 : -1;
	}
}