/** 
 * How to obtain access to all of the referenced libraries:
 * 
 * The sorting and graphing algorithms rely on the library algs4.jar, which can
 * be found at http://algs4.cs.princeton.edu/code/
 * 
 * The jxbrowser library jar files can all be downloaded at
 * https://www.teamdev.com/jxbrowser. They are available in the lib file, and
 * there is one in the demo file that also must be included.
 * 
 * The org.json.jar file can be found at
 * http://www.java2s.com/Code/Jar/o/Downloadorgjsonjar.htm
 * 
 */
package cas2xb3.greenlight;

import java.awt.BorderLayout;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import org.json.JSONException;

import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;
import edu.princeton.cs.algs4.*;

/**
 * The main class for Green Light. Gets the user to give a location and a
 * destination in Iowa, then calculates the safest path and outputs a path
 * formed by waypoints on a Google Maps map.
 * 
 * @author Gundeep Kanwal
 * @author Mediha Munim
 *
 */
public class GreenLight {

	// The origin, as entered by the user
	public static String origin;

	// The destination, as entered by the user
	public static String destination;

	/**
	 * Takes the inputs from the user, then converts them into
	 * latitude/longitude locations. Generates the graph of collision points and
	 * finds the path with the fewest/least important collisions from the origin
	 * to destination and generates a map image of the path. Makes use of all of
	 * the imported libraries.
	 * 
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		double originLat = 0;
		double originLng = 0;
		double destLat = 0;
		double destLng = 0;

		// Initialize and sort the collision array:

		Collision[] collisions = Data.getArray();
		Heap.sort(collisions);

		// Take the input from the user:

		try {
			Scanner sc = new Scanner(System.in);

			// Get the origin and turn it into lat/lng points:

			System.out.println("Enter the origin: ");
			origin = sc.nextLine();

			origin = GoogleMapsGeocoder.getCoordinates(origin);

			originLat = GoogleMapsGeocoder.getLatitude();
			originLng = GoogleMapsGeocoder.getLongitude();

			if (originLat > 43.51 || originLat < 40.22 || originLng > -90.15 || originLng < -96.65) {
				System.out.println("Origin is not in Iowa.");
				System.exit(0);
			}

			// Get the destination and turn it into lat/lng points:

			System.out.println("Enter the destination: ");
			destination = sc.nextLine();

			destination = GoogleMapsGeocoder.getCoordinates(destination);
			destLat = GoogleMapsGeocoder.getLatitude();
			destLng = GoogleMapsGeocoder.getLongitude();

			if (destLat > 43.51 || destLat < 40.22 || destLng > -90.15 || destLng < -96.65) {
				System.out.println("Destination is not in Iowa.");
				System.exit(0);
			}

		} catch (JSONException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// Find the collisions closest to the origin and destination:

		int originPointIndex = ClosestPoint.closest(collisions, originLat, originLng);
		int destPointIndex = ClosestPoint.closest(collisions, destLat, destLng);

		// Build the graph

		EdgeWeightedDigraph G = CrashGraph.FinalGraph();

		// Then find the shortest path from the origin to the destination:

		DijkstraSP sp = new DijkstraSP(G, originPointIndex);

		// Make the array of the collisions:

		ArrayList<Collision> tempCollisionPath = new ArrayList<Collision>();
		tempCollisionPath.add(collisions[originPointIndex]);

		if (sp.hasPathTo(destPointIndex)) {
			// System.out.printf("%s to %s (%.2f) ", origin, destination,
			// sp.distTo(destPointIndex));
			for (DirectedEdge e : sp.pathTo(destPointIndex)) {
				tempCollisionPath.add(collisions[e.to()]);
			}
		}

		Object[] collisionPath = tempCollisionPath.toArray();

		List<String> path = new ArrayList();

		for (int i = 0; i < collisionPath.length; i++) {
			path.add(((Collision) collisionPath[i]).getLat() + "," + ((Collision) collisionPath[i]).getLng());
		}

		// Modify the list so there are 23 or less waypoints:

		path = GoogleMapsDirectionsGenerator.modifyList(path);

		// Create and output the path using Google Maps:

		GoogleMapsDirectionsGenerator.userInput(path);

		final Browser browser = new Browser();
		BrowserView browserView = new BrowserView(browser);

		JFrame frame = new JFrame("Output Route");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.add(browserView, BorderLayout.CENTER);
		frame.setSize(1800, 1000);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		browser.loadHTML(GoogleMapsDirectionsGenerator.genHtml());

		GoogleMapsDirectionsGenerator.cleanup();
	}

}