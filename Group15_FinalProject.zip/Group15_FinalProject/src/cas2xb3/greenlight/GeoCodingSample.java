package cas2xb3.greenlight;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.*;

public class GeoCodingSample {

	private static JSONObject json;

	private static double longitude;

	private static double latitude;

	private static String lng;

	private static String lat;

	private static String ReplacementAddress;

	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
		InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}

	}

	public static String getCoordinates(String address) throws JSONException, IOException {

		if (address.contains(" ")) {

			for (int i = 0; i < address.length(); i++) {

				ReplacementAddress = address.replace(" ", "");

			}

			json = readJsonFromUrl("https://maps.googleapis.com/maps/api/geocode/json?address=" + ReplacementAddress
					+ "&key=AIzaSyAgOPBEIzwBTQmWbZHHApZfqi8sEbSmKy8");

		} else {

			json = readJsonFromUrl("https://maps.googleapis.com/maps/api/geocode/json?address=" + address
					+ "&key=AIzaSyAgOPBEIzwBTQmWbZHHApZfqi8sEbSmKy8");

		}

		json.getJSONArray("results").toList();

		String name = json.getJSONArray("results").toString();

		String[] test = name.split(",|}|:");

		for (int i = 0; i < test.length; i++) {

			if (test[i].equals('"' + "location" + '"')) {

				lng = test[i + 2];

				lat = test[i + 4];

			}

		}

		longitude = Double.parseDouble(lng);

		latitude = Double.parseDouble(lat);

		return (getLatitude() + " , " + getlongitude());

	}

	public static double getLatitude() {

		return latitude;

	}

	public static double getlongitude() {

		return longitude;

	}

}
