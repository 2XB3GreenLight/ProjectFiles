package cas2xb3.greenlight;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Math;

/**
 * This class is responsible for reading, accessing, and managing the data from
 * the Crash_Data dataset.
 * 
 * @author Mediha
 */
public class Data {

	// Number of collisions in the dataset
	static private int size = getCollisionCount();

	// Stores the collisions in an array
	static private Collision[] collisionArray = new Collision[size];

	/**
	 * Fills the collision array by creating collision objects from the dataset.
	 * 
	 * @return an array with only the important information. Also gives each row
	 *         an index to be referenced by
	 */
	public static Collision[] getArray() {

		// If the array has already been filled:
		if (collisionArray[0] != null) {
			return collisionArray;
		}

		try {
			BufferedReader br = new BufferedReader(new FileReader("data/Crash_Data.csv"));
			String line;

			// Put all the lines in the array (important information) with the
			// crash index:
			br.readLine();

			for (int i = 0; i < getCollisionCount(); i++) {
				line = br.readLine();
				if (line.charAt(0) == '2') { // Only consider the rows with
												// crash information
					String splitline[] = line.split(",");

					double lat = Double.valueOf(splitline[39].substring(2)); // LATITUDE
					double lng = -1 * Double.valueOf(splitline[40].substring(2, splitline[40].indexOf(')'))); // LONGITUDE
					int CSEV;
					if (!splitline[25].equals("")) {
						CSEV = Integer.valueOf(splitline[25]); // CSEV
					} else {
						CSEV = 5; // assume non-severe collision
					}
					int weather;
					if (Integer.valueOf(splitline[20]) <= 10) {
						weather = Integer.valueOf(splitline[20]); // WEATHER
					} else {
						weather = 5; // average weather
					}
					int paved;
					if (Integer.valueOf(splitline[23]) <= 2) {
						paved = Integer.valueOf(splitline[23]); // PAVED
					} else {
						paved = 1; // assume paved
					}

					collisionArray[i] = new Collision(i, lat, lng, CSEV, weather, paved);
				}
			}
			br.close();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return collisionArray;
	}

	/**
	 * Calculates and returns the total number of collisions.
	 * 
	 * @return the total number of collisions
	 */
	public static int getCollisionCount() {

		// If the size has already been calculated:
		if (size != 0) {
			return size;
		}

		// The first time it's calculated:
		try {
			BufferedReader br = new BufferedReader(new FileReader("data/Crash_Data.csv"));

			br.readLine(); // skip the first line in the dataset
			// Iterate through file line by line:
			while (br.readLine().charAt(0) == '2') {
				size++;
			}

			br.close();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		size--;
		return size;
	}


}