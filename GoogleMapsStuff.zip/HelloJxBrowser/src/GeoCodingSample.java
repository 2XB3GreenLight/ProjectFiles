import java.awt.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.*;

public class GeoCodingSample {
	
	static JSONObject json;

	static double longitude;
	
	static double latitude;

  private static String readAll(Reader rd) throws IOException {
    StringBuilder sb = new StringBuilder();
    int cp;
    while ((cp = rd.read()) != -1) {
      sb.append((char) cp);
    }
    return sb.toString();
  }

  public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
    InputStream is = new URL(url).openStream();
    try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = readAll(rd);
      JSONObject json = new JSONObject(jsonText);
      return json;
    } finally {
      is.close();
    }
    
  }
  
  public static void getCoordinates(String address) throws JSONException, IOException{
	  
	    json = readJsonFromUrl("https://maps.googleapis.com/maps/api/geocode/json?address=" + address + "&key=AIzaSyAgOPBEIzwBTQmWbZHHApZfqi8sEbSmKy8");
	  
	    json.getJSONArray("results").toList();
	    
	    String name = json.getJSONArray("results").toString();
	    
	    int n = name.indexOf("location");
	    	
	    String lng = name.substring(n + 17 , n + 29 );
	    
	    String lat = name.substring(n + 36 , n + 46 );
	    	    
	    if(lng.contains(",")){
	    	
	    	lng = name.substring(n + 17 , n + 28 );
	    	
	    	n = n - 1;
	    	
	    }
	    	    
	    if(lat.contains(",")){
	    	
	    	lat = name.substring(n + 36 , n + 45 );
	    	
	    }
	    
	    if(lat.contains("}")){
	    	
	    	lat = name.substring(n + 36 , n + 44 );
	    	
	    }
	    
	    longitude = Double.parseDouble(lng);

	    latitude = Double.parseDouble(lat);

	    System.out.println("For " + address + ": Latitude = " + getLatitude() + " , " + "Longitude = " + getlongitude());
	    	    
	  }
  
  public static double getLatitude(){
	  
	  return latitude;
	  
  }
  
 public static double getlongitude(){
	  
	  return longitude ;
	  
  }

  public static void main(String[] args) throws IOException, JSONException {

	  getCoordinates("Toronto");
	  
	  getCoordinates("NewYork");

  }
}
